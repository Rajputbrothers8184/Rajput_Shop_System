import psycopg2
from psycopg2 import OperationalError


class Database:
    def __init__(self):
        try:
            # Replace with your actual PostgreSQL credentials
            self.conn = psycopg2.connect(
                host="localhost",  # e.g., "localhost"
                user="postgres",  # e.g., "postgres"
                password="Rana@8184",  # Your PostgreSQL password
                database="rajput_shop"  # e.g., "shop_db"
            )
            self.cursor = self.conn.cursor()
            print("Database connected successfully.")
        except OperationalError as e:
            print(f"Database connection failed: {e}")
            self.conn = None
            self.cursor = None

    def execute_query(self, query, params=None):
        """Executes a query and commits the transaction."""
        if not self.conn or not self.cursor:
            print("No database connection available.")
            return False
        try:
            print(f"Executing query: {query} with params: {params}")
            self.cursor.execute(query, params)
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Query execution failed: {e}")
            return False

    def fetch_data(self, query, params=None):
        """Fetches data from the database."""
        if not self.conn or not self.cursor:
            print("No database connection available.")
            return []
        try:
            print(f"Fetching data with query: {query} and params: {params}")
            self.cursor.execute(query, params)
            return self.cursor.fetchall()
        except Exception as e:
            print(f"Data fetching failed: {e}")
            return []

    def commit(self):
        """Commits any pending transaction."""
        if self.conn:
            try:
                self.conn.commit()
                print("Transaction committed successfully.")
            except Exception as e:
                print(f"Commit failed: {e}")

    def close(self):
        """Closes the database connection."""
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()
        print("Database connection closed.")
