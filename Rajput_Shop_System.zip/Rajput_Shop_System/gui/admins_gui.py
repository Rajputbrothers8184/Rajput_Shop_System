import tkinter as tk
from tkinter import messagebox
from database import Database

class AdminsGUI:
    def __init__(self):
        self.db = Database()
        self.root = tk.Tk()
        self.root.title("Manage Admins")
        self.root.geometry("500x400")

        # Set background color for the root window
        self.root.configure(bg="#ff0000")

        # Labels and Entries
        tk.Label(self.root, text="Name:", bg="#f0f0f0", font=("Consolas", 12)).grid(row=0, column=0, padx=10, pady=10)
        tk.Label(self.root, text="Email:", bg="#f0f0f0", font=("Consolas", 12)).grid(row=1, column=0, padx=10, pady=10)
        tk.Label(self.root, text="Password:", bg="#f0f0f0", font=("Consolas", 12)).grid(row=2, column=0, padx=10, pady=10)

        self.name_entry = tk.Entry(self.root, font=("Consolas", 12))
        self.email_entry = tk.Entry(self.root, font=("Consolas", 12))
        self.password_entry = tk.Entry(self.root, show="*", font=("Consolas", 12))
        self.name_entry.grid(row=0, column=1, padx=10, pady=10)
        self.email_entry.grid(row=1, column=1, padx=10, pady=10)
        self.password_entry.grid(row=2, column=1, padx=10, pady=10)

        # Colorful Buttons
        tk.Button(
            self.root,
            text="Add Admin",
            command=self.add_admin,
            bg="#03055B",  
            fg="white",
            activebackground="#03055B",
            activeforeground="white",
            font=("Consolas", 10, "bold")
        ).grid(row=3, column=0, pady=10, padx=10)

        tk.Button(
            self.root,
            text="Show Admins",
            command=self.show_admins,
            bg="#03055B",  # Blue
            fg="white",
            activebackground="#03055B",
            activeforeground="white",
            font=("Consolas", 10, "bold")
        ).grid(row=3, column=1, pady=10, padx=10)

        # Output Text Box
        self.output_text = tk.Text(self.root, width=60, height=15, font=("Consolas", 12))
        self.output_text.grid(row=4, column=0, columnspan=2, pady=10)

        self.root.mainloop()

    def add_admin(self):
        """Adds a new admin to the database."""
        name = self.name_entry.get()
        email = self.email_entry.get()
        password = self.password_entry.get()

        # Validation for input fields
        if name and email and password:
            query = "INSERT INTO admins (name, email, password) VALUES (%s, %s, %s)"
            try:
                success = self.db.execute_query(query, (name, email, password))
                if success:
                    self.db.commit()  # Ensure changes are committed to the database
                    messagebox.showinfo("Success", "Admin added successfully!")
                    self.clear_entries()  # Clear input fields after adding
                else:
                    messagebox.showerror("Error", "Failed to add admin.")
            except Exception as e:
                messagebox.showerror("Database Error", f"Error: {e}")
        else:
            messagebox.showwarning("Warning", "All fields are required.")

    def show_admins(self):
        """Fetches and displays all admins from the database."""
        query = "SELECT * FROM admins"
        try:
            admins = self.db.fetch_data(query)
            self.output_text.delete(1.0, tk.END)  # Clear existing output
            if admins:
                for admin in admins:
                    self.output_text.insert(
                        tk.END, 
                        f"ID: {admin[0]}, Name: {admin[1]}, Email: {admin[2]}\n"
                    )
            else:
                self.output_text.insert(tk.END, "No admins found.\n")
        except Exception as e:
            messagebox.showerror("Database Error", f"Error: {e}")

    def clear_entries(self):
        """Clears the entry fields."""
        self.name_entry.delete(0, tk.END)
        self.email_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)


# Run the application
if __name__ == "__main__":
    AdminsGUI()
