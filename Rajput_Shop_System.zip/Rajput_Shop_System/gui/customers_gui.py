import tkinter as tk
from tkinter import messagebox
from database import Database

class CustomersGUI:
    def __init__(self):
        self.db = Database()
        self.root = tk.Tk()
        self.root.title("Manage Customers")
        self.root.geometry("500x400")

        # Set background color for the root window
        self.root.configure(bg="#ff0000")

        # Labels and Entries
        tk.Label(self.root, text="Name:", bg="#f0f0f0", font=("Consolas", 12)).grid(row=0, column=0, padx=10, pady=10)
        tk.Label(self.root, text="Phone:", bg="#f0f0f0", font=("Consolas", 12)).grid(row=1, column=0, padx=10, pady=10)

        self.name_entry = tk.Entry(self.root, font=("Consolas", 12))
        self.phone_entry = tk.Entry(self.root, font=("Consolas", 12))
        self.name_entry.grid(row=0, column=1, padx=10, pady=10)
        self.phone_entry.grid(row=1, column=1, padx=10, pady=10)

        # Colorful Buttons
        tk.Button(
            self.root,
            text="Add Customer",
            command=self.add_customer,
            bg="#03055B",  # Green
            fg="white",
            activebackground="#03055B",
            activeforeground="white",
            font=("Consolas", 10, "bold")
        ).grid(row=2, column=0, pady=10, padx=10)

        tk.Button(
            self.root,
            text="Show Customers",
            command=self.show_customers,
            bg="#03055B",  # Blue
            fg="white",
            activebackground="#03055B",
            activeforeground="white",
            font=("Consolas", 10, "bold")
        ).grid(row=2, column=1, pady=10, padx=10)

        # Output Text Box
        self.output_text = tk.Text(self.root, width=60, height=15, font=("Consolas", 12))
        self.output_text.grid(row=3, column=0, columnspan=2, pady=10)

        self.root.mainloop()

    def add_customer(self):
        """Adds a new customer to the database."""
        name = self.name_entry.get()
        phone = self.phone_entry.get()

        # Validation for input fields
        if name and phone:
            query = "INSERT INTO customers (name, phone) VALUES (%s, %s)"
            try:
                success = self.db.execute_query(query, (name, phone))
                if success:
                    self.db.commit()  # Ensure changes are committed to the database
                    messagebox.showinfo("Success", "Customer added successfully!")
                    self.clear_entries()  # Clear input fields after adding
                else:
                    messagebox.showerror("Error", "Failed to add customer.")
            except Exception as e:
                messagebox.showerror("Database Error", f"Error: {e}")
        else:
            messagebox.showwarning("Warning", "All fields are required.")

    def show_customers(self):
        """Fetches and displays all customers from the database."""
        query = "SELECT * FROM customers"
        try:
            customers = self.db.fetch_data(query)
            self.output_text.delete(1.0, tk.END)  # Clear existing output
            if customers:
                for customer in customers:
                    self.output_text.insert(
                        tk.END, 
                        f"ID: {customer[0]}, Name: {customer[1]}, Phone: {customer[2]}\n"
                    )
            else:
                self.output_text.insert(tk.END, "No customers found.\n")
        except Exception as e:
            messagebox.showerror("Database Error", f"Error: {e}")

    def clear_entries(self):
        """Clears the entry fields."""
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)


# Run the application
if __name__ == "__main__":
    CustomersGUI()
