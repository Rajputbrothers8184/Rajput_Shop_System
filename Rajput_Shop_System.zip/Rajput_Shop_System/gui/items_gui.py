import tkinter as tk
from tkinter import messagebox
from database import Database

class ItemsGUI:
    def __init__(self):
        self.db = Database()
        self.root = tk.Tk()
        self.root.title("Manage Items")
        self.root.geometry("500x400")

        # Set background color for the root window
        self.root.configure(bg="#ff0000")

        # Labels and Entries
        tk.Label(self.root, text="Item Name", bg="#f0f0f0", font=("Consolas", 12)).grid(row=0, column=0, padx=10, pady=10)
        tk.Label(self.root, text="Item Price", bg="#f0f0f0", font=("Consolas", 12)).grid(row=1, column=0, padx=10, pady=10)
        tk.Label(self.root, text="Item Stock", bg="#f0f0f0", font=("Consolas", 12)).grid(row=2, column=0, padx=10, pady=10)

        self.name_entry = tk.Entry(self.root, font=("Consolas", 12))
        self.price_entry = tk.Entry(self.root, font=("Consolas", 12))
        self.stock_entry = tk.Entry(self.root, font=("Consolas", 12))
        self.name_entry.grid(row=0, column=1, padx=10, pady=10)
        self.price_entry.grid(row=1, column=1, padx=10, pady=10)
        self.stock_entry.grid(row=2, column=1, padx=10, pady=10)

        # Colorful Buttons
        tk.Button(
            self.root,
            text="Add Item",
            command=self.add_item,
            bg="#03055B",  # Green
            fg="white",
            activebackground="#03055B",
            activeforeground="white",
            font=("Consolas", 10, "bold")
        ).grid(row=3, column=0, pady=10, padx=10)

        tk.Button(
            self.root,
            text="Show Items",
            command=self.show_items,
            bg="#03055B",  # Blue
            fg="white",
            activebackground="#03055B",
            activeforeground="white",
            font=("Consolas", 10, "bold")
        ).grid(row=3, column=1, pady=10, padx=10)

        # Output Text Box
        self.output_text = tk.Text(self.root, width=60, height=15, font=("Consolas", 12))
        self.output_text.grid(row=4, column=0, columnspan=2, pady=10)

        self.root.mainloop()

    def add_item(self):
        """Adds a new item to the database."""
        name = self.name_entry.get()
        price = self.price_entry.get()
        stock = self.stock_entry.get()

        # Validation for input fields
        if name and price and stock:
            try:
                price = float(price)  # Ensure price is a valid float
                stock = int(stock)  # Ensure stock is a valid integer
                query = "INSERT INTO items (name, price, stock) VALUES (%s, %s, %s)"
                success = self.db.execute_query(query, (name, price, stock))
                if success:
                    self.db.commit()  # Ensure changes are committed to the database
                    messagebox.showinfo("Success", "Item added successfully!")
                    self.clear_entries()  # Clear input fields after adding
                else:
                    messagebox.showerror("Error", "Failed to add item.")
            except ValueError:
                messagebox.showerror("Error", "Price must be a numeric value and stock must be an integer.")
            except Exception as e:
                messagebox.showerror("Database Error", f"Error: {e}")
        else:
            messagebox.showwarning("Warning", "All fields are required.")

    def show_items(self):
        """Fetches and displays all items from the database."""
        query = "SELECT * FROM items"
        try:
            items = self.db.fetch_data(query)
            self.output_text.delete(1.0, tk.END)  # Clear existing output
            if items:
                for item in items:
                    self.output_text.insert(
                        tk.END, 
                        f"ID: {item[0]}, Name: {item[1]}, Price: {item[2]}, Stock: {item[3]}\n"
                    )
            else:
                self.output_text.insert(tk.END, "No items found.\n")
        except Exception as e:
            messagebox.showerror("Database Error", f"Error: {e}")

    def clear_entries(self):
        """Clears the entry fields."""
        self.name_entry.delete(0, tk.END)
        self.price_entry.delete(0, tk.END)
        self.stock_entry.delete(0, tk.END)


# Run the application
if __name__ == "__main__":
    ItemsGUI()
