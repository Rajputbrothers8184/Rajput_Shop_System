import tkinter as tk
from tkinter import messagebox
from database import Database

class StaffGUI:
    def __init__(self):
        self.db = Database()
        self.root = tk.Tk()
        self.root.title("Manage Staff")
        self.root.geometry("500x400")

        # Set background color to red for the root window
        self.root.configure(bg="#ff0000")  # Red background

        # Labels and Entries with white text for contrast
        tk.Label(self.root, text="Name", bg="#f0f0f0", fg="white", font=("Consolas", 12)).grid(row=0, column=0, padx=10, pady=10)
        tk.Label(self.root, text="Role", bg="#f0f0f0", fg="white", font=("Consolas", 12)).grid(row=1, column=0, padx=10, pady=10)
        tk.Label(self.root, text="Salary", bg="#f0f0f0", fg="white", font=("Consolas", 12)).grid(row=2, column=0, padx=10, pady=10)

        self.name_entry = tk.Entry(self.root, font=("Consolas", 12))
        self.role_entry = tk.Entry(self.root, font=("Consolas", 12))
        self.salary_entry = tk.Entry(self.root, font=("Consolas", 12))
        self.name_entry.grid(row=0, column=1, padx=10, pady=10)
        self.role_entry.grid(row=1, column=1, padx=10, pady=10)
        self.salary_entry.grid(row=2, column=1, padx=10, pady=10)

        # Colorful Buttons with contrasting colors
        tk.Button(
            self.root,
            text="Add Staff",
            command=self.add_staff,
            bg="#03055B",  # Green
            fg="white",
            activebackground="#03055B",
            activeforeground="white",
            font=("Consolas", 10, "bold")
        ).grid(row=3, column=0, pady=10, padx=10)

        tk.Button(
            self.root,
            text="Show Staff",
            command=self.show_staff,
            bg="#03055B",  # Blue
            fg="white",
            activebackground="#03055B",
            activeforeground="white",
            font=("Consolas", 10, "bold")
        ).grid(row=3, column=1, pady=10, padx=10)

        # Output Text Box with white background and black text
        self.output_text = tk.Text(self.root, width=60, height=15, font=("Arial", 12), bg="#ffffff", fg="#000000")
        self.output_text.grid(row=4, column=0, columnspan=2, pady=10)

        self.root.mainloop()

    def add_staff(self):
        """Adds a new staff member to the database."""
        name = self.name_entry.get()
        role = self.role_entry.get()
        salary = self.salary_entry.get()

        # Validation for input fields
        if name and role and salary:
            try:
                salary = float(salary)  # Ensure salary is a valid float
                query = "INSERT INTO staff (name, role, salary) VALUES (%s, %s, %s)"
                success = self.db.execute_query(query, (name, role, salary))
                if success:
                    self.db.commit()  # Ensure changes are committed to the database
                    messagebox.showinfo("Success", "Staff added successfully!")
                    self.clear_entries()  # Clear input fields after adding
                else:
                    messagebox.showerror("Error", "Failed to add staff.")
            except ValueError:
                messagebox.showerror("Error", "Salary must be a numeric value.")
            except Exception as e:
                messagebox.showerror("Database Error", f"Error: {e}")
        else:
            messagebox.showwarning("Warning", "All fields are required.")

    def show_staff(self):
        """Fetches and displays all staff members from the database."""
        query = "SELECT * FROM staff"
        try:
            staff = self.db.fetch_data(query)
            self.output_text.delete(1.0, tk.END)  # Clear existing output
            if staff:
                for staff_member in staff:
                    self.output_text.insert(
                        tk.END, 
                        f"ID: {staff_member[0]}, Name: {staff_member[1]}, Role: {staff_member[2]}, Salary: {staff_member[3]}\n"
                    )
            else:
                self.output_text.insert(tk.END, "No staff found.\n")
        except Exception as e:
            messagebox.showerror("Database Error", f"Error: {e}")

    def clear_entries(self):
        """Clears the entry fields."""
        self.name_entry.delete(0, tk.END)
        self.role_entry.delete(0, tk.END)
        self.salary_entry.delete(0, tk.END)


# Run the application
if __name__ == "__main__":
    StaffGUI()
