import tkinter as tk
from gui.admins_gui import AdminsGUI
from gui.staff_gui import StaffGUI
from gui.items_gui import ItemsGUI
from gui.customers_gui import CustomersGUI

def main():
    root = tk.Tk()
    root.title("Rajput Shop System")
    root.geometry("400x400")

    # Set Background Color
    root.configure(bg="#ff0000")

    # Title Frame for Box Effect
    title_frame = tk.Frame(root, bg="#03055B", bd=5, relief="ridge")  # Green box with border
    title_frame.pack(pady=20, padx=20, fill="x")  # Padding for spacing

    # Header Label Inside the Frame
    tk.Label(
        title_frame,
        text="Rajput Shop System",
        font=("Consolas", 18, "bold"),
        bg="#032B44",  # Match the frame background
        fg="white"
    ).pack(pady=10)

    # Buttons with Different Colors
    tk.Button(
        root,
        text="Manage Admins",
        command=AdminsGUI,
        font=("Consolas", 12),
        bg="#03055B",  
        fg="white",
        activebackground="#03055B",
        activeforeground="white",
        width=20,
        height=2
    ).pack(pady=10)

    tk.Button(
        root,
        text="Manage Staff",
        command=StaffGUI,
        font=("Consolas", 12),
        bg="#03055B",  
        fg="white",
        activebackground="#03055B",
        activeforeground="white",
        width=20,
        height=2
    ).pack(pady=10)

    tk.Button(
        root,
        text="Manage Items",
        command=ItemsGUI,
        font=("Consolas", 12),
        bg="#03055B",  
        fg="white",
        activebackground="#03055B",
        activeforeground="white",
        width=20,
        height=2
    ).pack(pady=10)

    tk.Button(
        root,
        text="Manage Customers",
        command=CustomersGUI,
        font=("Consolas", 12),
        bg="#03055B",  # Pink
        fg="white",
        activebackground="#03055B",
        activeforeground="white",
        width=20,
        height=2
    ).pack(pady=10)

    # Exit Button
    tk.Button(
        root,
        text="Exit",
        command=root.destroy,
        font=("Consolas", 12),
        bg="#03055B",  # Red
        fg="white",
        activebackground="#03055B",
        activeforeground="white",
        width=20,
        height=2
    ).pack(pady=20)

    root.mainloop()

if __name__ == "__main__":
    main()
